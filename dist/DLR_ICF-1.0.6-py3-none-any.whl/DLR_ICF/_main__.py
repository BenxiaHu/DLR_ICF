from .DLR_ICF_main import main
main()

from .DLR_ICF_comparison import main
main()

from .DLR_ICF_separation import main
main()

from .ICF_chromatin import main
main()
